#ifndef SYSTEM_BOARD_H_
#define SYSTEM_BOARD_H_

#define XT_PORT_SEL0                              P2SEL0
#define XT_PORT_SEL1                              P2SEL1
#define XT_OUT_PIN                                BIT6
#define XT_IN_PIN                                 BIT7

#endif /* SYSTEM_BOARD_H_ */
