#include "sysconf.h"

unsigned int Setup_senseCount = 0;
float V_vp = 0;
unsigned int V_stopFlag = 1;
unsigned int SS_stopFlag = 1;
unsigned int SS_exceptionFlag = 0;
